# Cosmic Lens

## Cloud Deployment (No Install Required)

1.  **Upload Files:** Upload all these files to your GitHub repository.
2.  **Activate Deployment:**
    *   Go to your Repository **Settings** tab.
    *   Click **Pages** on the left menu.
    *   Under **Build and deployment** > **Source**, select **GitHub Actions** (Beta).
3.  **Wait:** GitHub will automatically build your site. In about 2 minutes, the URL will appear at the top of that Settings page.
4.  **Connect:** Open the site, click the Settings icon, and paste your Gemini API Key.
