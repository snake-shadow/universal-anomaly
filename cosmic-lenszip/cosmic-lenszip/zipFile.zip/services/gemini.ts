import { GoogleGenAI, Type } from "@google/genai";
import { FactResponse } from "../types";

// STORAGE KEY
const STORAGE_KEY = 'gemini_api_key_override';

// 1. Check Environment Variable (Build time)
// 2. Check Local Storage (Runtime override)
const getApiKey = (): string | null => {
  const envKey = process.env.API_KEY;
  if (envKey && envKey !== "undefined" && envKey !== "") return envKey;
  
  const localKey = localStorage.getItem(STORAGE_KEY);
  if (localKey && localKey !== "undefined" && localKey !== "") return localKey;

  return null;
};

export const hasValidKey = (): boolean => {
    return !!getApiKey();
};

export const saveApiKey = (key: string) => {
    localStorage.setItem(STORAGE_KEY, key);
    window.location.reload(); // Reload to re-initialize services
};

export const clearApiKey = () => {
    localStorage.removeItem(STORAGE_KEY);
    window.location.reload();
};

const modelName = 'gemini-2.5-flash';

// --- DEMO / OFFLINE DATA ---
const DEMO_FACTS: Record<string, FactResponse> = {
    'STAR': {
        title: "Distant Star (Database)",
        content: "A massive, luminous sphere of plasma held together by its own gravity. The ship's sensors are currently relying on pre-cached data rather than live spectral analysis.",
        funFact: "The light you see from some stars left them before civilizations existed on Earth."
    },
    'PLANET': {
        title: "Exoplanet (Database)",
        content: "A rocky or gaseous world orbiting a distant star. Without the live AI uplink, detailed atmospheric composition analysis is unavailable.",
        funFact: "There are likely more planets in the universe than grains of sand on all of Earth's beaches."
    },
    'NEBULA': {
        title: "Nebula Cloud (Database)",
        content: "A vast cloud of dust and gas. These are often stellar nurseries. In simulation mode, we display a generalized structure rather than specific chemical composition.",
        funFact: "Nebulae come in many shapes, leading to names like 'Horsehead', 'Crab', and 'Eye of God'."
    },
    'BLACK_HOLE': {
        title: "Singularity (Database)",
        content: "A region of spacetime where gravity is so strong that nothing can escape. The ship's computer is simulating the event horizon visuals based on general relativity models.",
        funFact: "If you fell into a black hole, you would be stretched out like spaghetti in a process called 'spaghettification'."
    },
    'ANOMALY': {
        title: "Unidentified Anomaly",
        content: "The ship's sensors are picking up a high-energy signature in this sector. Due to limited uplink connectivity, the exact nature of this phenomenon—whether a wormhole or spatial rift—cannot be determined.",
        funFact: "Dark matter makes up about 27% of the universe, yet it remains invisible to direct detection."
    }
};

// Hardcoded data for the suggested search terms so the buttons work offline
const OFFLINE_SEARCH_RESULTS: Record<string, FactResponse> = {
  "boötes void": {
    title: "BOÖTES VOID (OFFLINE ARCHIVE)",
    content: "One of the largest known voids in the universe, often referred to as 'The Great Nothing'. Spanning approximately 330 million light-years in diameter, it contains very few galaxies. If our galaxy were in the center of the Boötes Void, we wouldn't have known other galaxies existed until the 1960s.",
    funFact: "It is estimated that if the void were a typical region of space, it should contain thousands of galaxies, but only about 60 have been found."
  },
  "encke gap": {
    title: "ENCKE GAP (OFFLINE ARCHIVE)",
    content: "A 325-kilometer-wide gap within the A Ring of Saturn. It is kept open by the presence of a small moonlet named Pan, which orbits within the gap and acts as a shepherd moon, clearing particles from its path.",
    funFact: "The moon Pan creates wake patterns in the ring particles that look like ripples."
  },
  "great attractor": {
    title: "GREAT ATTRACTOR (OFFLINE ARCHIVE)",
    content: "A gravitational anomaly in intergalactic space and the central gravitational point of the Laniakea Supercluster. It reveals the existence of a localized concentration of mass tens of thousands of times more massive than the Milky Way.",
    funFact: "We are being pulled towards it at over a million miles per hour, but we can't see it because it's hidden behind the 'Zone of Avoidance'."
  },
  "oort cloud": {
    title: "OORT CLOUD (OFFLINE ARCHIVE)",
    content: "A theoretical spherical shell of icy objects that is believed to surround the Sun at a distance of up to 100,000 AU. It is thought to be the origin of long-period comets.",
    funFact: "No spacecraft has yet reached the Oort Cloud; Voyager 1 will take about 300 years to reach the inner edge."
  },
  "diamond planet": {
    title: "55 CANCRI E (OFFLINE ARCHIVE)",
    content: "An exoplanet that is twice the size of Earth but eight times its mass. Due to its pressure and carbon-rich composition, scientists believe a significant portion of its mass could be pure diamond.",
    funFact: "This 'diamond super-Earth' is so hot that its surface is likely covered in lava."
  },
  "pillars of creation": {
    title: "PILLARS OF CREATION (OFFLINE ARCHIVE)",
    content: "Elephant trunks of interstellar gas and dust in the Eagle Nebula. They are in the process of creating new stars, while simultaneously being eroded by the light from nearby massive stars.",
    funFact: "They were actually destroyed by a supernova 6000 years ago, but the light of the destruction won't reach Earth for another millennium."
  }
};

// Helper to get AI instance on demand
const getAI = (): GoogleGenAI | null => {
    const key = getApiKey();
    if (!key) return null;
    return new GoogleGenAI({ apiKey: key });
};

export const getObjectFact = async (objectType: string, objectName: string): Promise<FactResponse> => {
  const ai = getAI();

  // FALLBACK: If no key, return generic simulation data immediately
  if (!ai) {
    await new Promise(resolve => setTimeout(resolve, 800)); // Fake network delay for realism
    const defaultFact = DEMO_FACTS[objectType] || DEMO_FACTS['STAR'];
    return {
        ...defaultFact,
        title: `${objectName} (Simulation)`
    };
  }

  try {
    const prompt = `
      Tell me a fascinating, scientific, yet accessible fact about a generic ${objectName} (${objectType}) in space.
      Keep it short (max 2-3 sentences).
      Also provide a separate "Mind-Blowing Fun Fact".
      Return strictly JSON.
    `;

    const response = await ai.models.generateContent({
      model: modelName,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            content: { type: Type.STRING },
            funFact: { type: Type.STRING },
          },
          required: ["title", "content", "funFact"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    
    return JSON.parse(text) as FactResponse;
  } catch (error: any) {
    console.error("Gemini Error:", error);
    
    // If we HAVE a key but it failed, tell the user why (don't just silently show demo data)
    return {
        title: "Uplink Error",
        content: `Connection to the Galactic AI failed. Please check your API quota or network connection. Error: ${error.message || "Unknown Error"}`,
        funFact: "Even in the future, communication networks can go down."
    };
  }
};

export const searchPhenomena = async (query: string): Promise<FactResponse> => {
  const ai = getAI();

  if (!ai) {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const lowerQuery = query.toLowerCase();
    // Check for offline match in the hardcoded database
    if (OFFLINE_SEARCH_RESULTS[lowerQuery]) {
        return OFFLINE_SEARCH_RESULTS[lowerQuery];
    }

    return {
      title: "Offline Mode",
      content: `You searched for "${query}". The ship's long-range sensors (AI) are offline. Try clicking one of the suggested topics (like 'Boötes Void') to access cached data, or configure your API Key to enable full search.`,
      funFact: "The universe is waiting for you to connect."
    };
  }

  try {
    const prompt = `
      You are an expert astronomer. The user is searching for "${query}".
      Provide a concise explanation of this space phenomenon.
      If it's a specific object (like Encke Gap, Bootes Void), explain what makes it unusual.
      Include a "Mind-Blowing Fun Fact".
      Use the Google Search tool to ensure accuracy if it is a specific real-world entity.
    `;

    const response = await ai.models.generateContent({
      model: modelName,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      }
    });

    const text = response.text || "";
    
    // Extract grounding
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const groundingUrls = groundingChunks
      .map(c => c.web)
      .filter(w => w !== undefined && w !== null)
      .map(w => ({ title: w.title || "Source", uri: w.uri || "#" }));

    return {
      title: query.toUpperCase(),
      content: text,
      funFact: "Check the sources for more deep dives!", 
      groundingUrls
    };

  } catch (error: any) {
    console.error("Gemini Search Error:", error);
    return {
      title: "Search Failed",
      content: `We could not complete your search for "${query}" due to a transmission error: ${error.message || "Signal Lost"}`,
      funFact: "Try simplifying your query or checking the ship's settings.",
      groundingUrls: []
    };
  }
};